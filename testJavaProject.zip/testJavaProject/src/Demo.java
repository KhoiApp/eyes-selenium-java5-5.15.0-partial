

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.StdoutLogHandler;
import com.applitools.eyes.TestResultsSummary;
import com.applitools.eyes.config.Configuration;
import com.applitools.eyes.selenium.BrowserType;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.selenium.StitchMode;
import com.applitools.eyes.selenium.fluent.Target;
import com.applitools.eyes.visualgrid.model.DeviceName;
import com.applitools.eyes.visualgrid.model.IosDeviceInfo;
import com.applitools.eyes.visualgrid.model.IosDeviceName;
import com.applitools.eyes.visualgrid.model.IosVersion;
import com.applitools.eyes.visualgrid.model.ScreenOrientation;
import com.applitools.eyes.visualgrid.services.RunnerOptions;
import com.applitools.eyes.visualgrid.services.VisualGridRunner;

public class Demo {
    
    private static WebDriver driver;
    
	public static void main(String[] args) {
		try {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			initEyes();
	        
	        driver = eyes.open(driver,"DemoApp","Demo", new RectangleSize(1000,600));
	        eyes.setLogHandler(new StdoutLogHandler(true));
	        
	        driver.get("https://demo.applitools.com/");
	        
	      
	        eyes.check(Target.window().fully().layoutBreakpoints(true));
	     
	        eyes.closeAsync();
	        
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
	        driver.quit();
	        
	    
	     	// Print results
	        TestResultsSummary allTestResults = runner.getAllTestResults(false);
			System.out.println(allTestResults);

		}
		
        
	}
	
	//private static EyesRunner runner = new ClassicRunner();
	private static EyesRunner runner = new VisualGridRunner(new RunnerOptions().testConcurrency(5));
    private static Eyes eyes = new Eyes(runner);
	
	
	
	private static Configuration config;
    private static BatchInfo batch;
	    
	private static void initEyes() {
		eyes.setApiKey("");
        
        config = eyes.getConfiguration();
        config.addBrowser(900, 600, BrowserType.CHROME);
        config.addBrowser(1200, 800, BrowserType.SAFARI);
        
        config.addBrowser(new IosDeviceInfo(IosDeviceName.iPhone_13_Pro_Max));
        config.addBrowser(new IosDeviceInfo(IosDeviceName.iPhone_13_Pro));
        config.addBrowser(new IosDeviceInfo(IosDeviceName.iPhone_12_mini));
        config.addBrowser(new IosDeviceInfo(IosDeviceName.iPhone_12_mini, IosVersion.ONE_VERSION_BACK));
        config.addDeviceEmulation(DeviceName.iPhone_X, ScreenOrientation.PORTRAIT);
        config.addDeviceEmulation(DeviceName.Pixel_2_XL, ScreenOrientation.PORTRAIT);
        config.addDeviceEmulation(DeviceName.iPad_Pro, ScreenOrientation.PORTRAIT);
        config.addDeviceEmulation(DeviceName.Galaxy_S20, ScreenOrientation.PORTRAIT);
        config.addDeviceEmulation(DeviceName.Pixel_5, ScreenOrientation.PORTRAIT);
        config.setDisableBrowserFetching(true);
        eyes.setConfiguration(config);
        
        eyes.setStitchMode(StitchMode.CSS);
        
        batch = new BatchInfo("Nightly");
        batch.setSequenceName("Nightly");
        batch.addProperty("appName", "Test");
        batch.addProperty("appName", "Test2");
        batch.setNotifyOnCompletion(true);
        
        eyes.setBatch(batch);
	}

}
