package appium.web.test;

//import com.applitools.eyes.EyesWebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.rmi.Remote;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.selenium.StitchMode;
import com.applitools.eyes.selenium.fluent.Target;

//import io.appium.java_client.android.AndroidDriver;


class Charter_38124 {

    public static void main(String[] args) throws MalformedURLException {

        // Initialize the eyes SDK and set your private API key.
        Eyes eyes = new Eyes(new ClassicRunner());
        eyes.setApiKey("<YOUR API KEY>");
        
        final String AUTOMATE_USERNAME = "<YOUR BS USERNAME>";
        final String AUTOMATE_ACCESS_KEY = "<YOUR BS KEY>";
        final String URL = "https://" + AUTOMATE_USERNAME + ":" + AUTOMATE_ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";
        

        MutableCapabilities capabilities = new MutableCapabilities();
    	HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();
    	//browserstackOptions.put("osVersion", "16");
    	browserstackOptions.put("deviceName", "iPhone 14 Pro Max"); // //Samsung Galaxy S9 Plus
    	browserstackOptions.put("projectName", "One Ryder Websites");
    	browserstackOptions.put("sessionName", "One Ryder Website Regression POC");
    	browserstackOptions.put("local", "false");
    	capabilities.setCapability("bstack:options", browserstackOptions);
    	
    	
    	/*
        // Set the desired capabilities.
        DesiredCapabilities dc = new DesiredCapabilities();

        dc.setCapability("platformName", "Android");
        //dc.setCapability("platformVersion", "PLATFORM_VERSION");
        dc.setCapability("browserName", "Chrome");
        //dc.setCapability("deviceName", "Pixel_3a_API_30_x86");
        dc.setCapability("device", "Samsung Galaxy S9 Plus");
        dc.setCapability("autoDismissAlerts", true);
        
        */
        
        eyes.setHideCaret(true);
        eyes.setSendDom(false);
        eyes.setHideScrollbars(true);

        eyes.setStitchMode(StitchMode.CSS);     

        eyes.setForceFullPageScreenshot(true);
        
        

        // Open browser.
        //WebDriver driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), dc);
        //WebDriver driver = new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), dc);
        //WebDriver driver = new RemoteWebDriver(new URL(URL), dc);
        WebDriver driver = new RemoteWebDriver(new URL(URL), capabilities);
        
        System.out.println(driver);
        
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.manage().window().maximize();

        try {

            // Start the test.
            eyes.open(driver, "Charter", "38124");

            // Navigate the browser to the "hello world!" web-site.
            driver.get("http://business.spectrum.com/");
 
            /*
            WebElement closeButton = driver.findElement(By.cssSelector("#email-capture-form-modal > div > div > div.modal-body > button"));
            closeButton.click();
            
            WebElement element = driver.findElement(By.id("button-217efd92ff"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-250);");
            element.click();
*/

            //eyes.check(Target.region(By.id("webLeadForm-9765211ff4")).fully(true));
           // eyes.check(Target.region(By.cssSelector("#HomepageModal > .modal-dialog > .modal-content")).fully(true));

            eyes.check(Target.window().fully());
            // End the test.
            eyes.close(false);

        } finally {

            // Close the browser.
            driver.quit();

            // If the test was aborted before eyes.close was called, ends the test as aborted.
            eyes.abortIfNotClosed();

        }
    }
}
